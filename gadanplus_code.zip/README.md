# gadanplus — GADA-N⁺ evaluation harness (reference implementation)

A runnable scaffold for the experiments in *"Deceiving the Thinking Adversary."*
It wires together: a CPS mission-network simulation, a ReAct LLM-attacker loop,
the LCAM deception layer, and the full metrics/stats/figures pipeline (HCR, MADT,
RCDI, DDR, suspicion AUROC, …) with reproducibility provenance and an
oracle-leakage audit.

> ⚠️ **READ THIS FIRST — integrity notice.**
> The environment dynamics in `env.py` are a **simplified reference stand-in**
> for building and testing the pipeline. They are **NOT** the validated GADA-N
> model. Any numbers produced by the mock/reference path are printed with a
> `NOT PAPER DATA` banner and stamped into every emitted table/figure, and must
> **never** be reported as experimental results.
> Before you report anything: (1) replace the env internals with your real
> GADA-N environment, (2) use the real GPT-4o / Llama backends, (3) freeze
> `PREREG.md`, and (4) complete ARL prepublication clearance.

## Quick start (smoke test — no GPU, no API key)
```bash
pip install -r requirements.txt
# one condition:
python -m gadanplus.run --defence gadanplus --attacker mock --seeds 3 --episodes 20
# whole pipeline (runs -> metrics -> leakage audit -> tables -> figures):
python -m gadanplus.run_conditions --suite configs/suite_smoke.yaml
```
Both print a `NOT PAPER DATA` summary; the suite writes tables/figures under
`results/smoke_suite/`.

## Real runs (your infra)
```bash
export OPENAI_API_KEY=...            # GPT-4o (eval-only, black-box transfer)
export LLAMA_ENDPOINT=...            # Llama-3.1-70B via vLLM (surrogate + eval)
export GPT4O_MODEL=gpt-4o-2024-08-06 # pin the snapshot; it is logged
python -m gadanplus.run_conditions --suite configs/suite_main.yaml       # C1–C5
python -m gadanplus.run_conditions --suite configs/suite_adaptive.yaml   # C6a–C6c
python -m gadanplus.run_conditions --suite configs/suite_robustness.yaml # 3 paraphrases
```

## Layout
```
gadanplus/
  env.py            # CPS sim + presentation-id renderer + LCAM + leakage contract
  attacker.py       # backends (mock/gpt4o/llama) + A0–A3 prompts (3 paraphrases)
                    #   + crash-safe cache + malformed-output exclusion + ReAct loop
  metrics.py        # HCR(+Clopper–Pearson), MADT, RCDI (+length-norm, ρ_decoy corr,
                    #   human-sample export, Cohen's κ), KCSD, ΔQoS, DDR, suspicion AUROC
  stats.py          # Welch t, Mann–Whitney U, Cohen's d, Cliff's δ, Shapiro gate,
                    #   Holm–Bonferroni, bootstrap CIs, fast rank-based AUROC
  integrity.py      # run provenance (git/config/renderer/PREREG hashes, libs)
                    #   + leakage_scan (single-field decoy-oracle audit)
  figures.py        # awareness-ladder curve + per-stage RCDI (CSV always; PNG/PDF)
  run.py            # single-condition CLI + reusable run_condition()
  run_conditions.py # suite driver: runs a suite YAML, emits tables.tex + figures
configs/            # suite_smoke / suite_main / suite_adaptive / suite_robustness
PREREG.md           # freeze hypotheses + thresholds BEFORE running C6
tests/              # pipeline invariants (no network needed): pytest -q
requirements.txt
```

## Integrity guarantees baked into the harness
- **No oracle leakage.** Nodes are rendered under opaque presentation ids from a
  shared namespace; real and decoy views share one field schema; coherence /
  corroboration / attractiveness distributions overlap. `integrity.leakage_scan`
  fails the run if any single exposed field (near-)perfectly separates decoys —
  the Paper-2 `attack_progress` lesson. Run it before trusting DDR / AUROC.
- **Reproducibility.** Every run writes a manifest with the git commit, config
  hash, renderer version-hash, PREREG hash, and library versions. Figures are
  regenerated from saved CSVs. Seeds are fixed per (seed, episode).
- **Run integrity.** Malformed LLM output is retried then excluded per the
  pre-registered rule (never crashes a large run); the response cache is
  append-only JSONL (a mid-run crash never corrupts prior cached calls).

## Integration points (where to plug in the real system)
- `env.py :: CPSEnv` transition + `LCAM` → replace with your GADA-N transition
  model and cGAN/GDE output. Keep the presentation-id + schema contract so
  `leakage_scan` stays clean. Train the generator with `L_ling` computed on the
  **Llama surrogate**; keep GPT-4o eval-only (surrogate→transfer framing).
- `attacker.py :: LlamaBackend / GPT4oBackend` → point at your endpoints (they
  already pin/log the snapshot, retry, and cache).
- `metrics.py :: label_step / export_human_sample` → the deterministic RCDI rule
  checker; export the 10% human-validation sample and compute Cohen's κ.
- Unimplemented baselines (C4 PPO, `gan_ids`, `honeypot`) are marked TODO in the
  configs — wire in the real controllers before running them.
