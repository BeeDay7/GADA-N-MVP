# Pre-registration — GADA-N⁺ evaluation (FREEZE BEFORE RUNNING C6)

**Freeze date:** ____________   **Git commit:** ____________
Fill the bracketed thresholds, commit this file, and do **not** edit it after runs begin.

## Environment & models
- Environment: [describe the ACTUAL GADA-N environment used — not the reference stand-in].
- Surrogate (L_ling training): Llama-3.1-70B (open weights).
- Attackers (eval): GPT-4o (pinned snapshot: ____________, black-box transfer), Llama-3.1-70B (in-distribution).
- Scale: 40 seeds × 100 episodes per condition.

## Primary hypotheses (H1–H6 — as in the manuscript)
- H1: HCR = 0 for GADA-N⁺ vs both attackers (report with Clopper–Pearson upper bound).
- H2: MADT(GADA-N⁺) > MADT(GADA-N-naive), Welch t, Holm-Bonferroni, d ≥ 0.2.
- H3: GADA-N-naive HCR > 0 vs GPT-4o.
- H4: RCDI(GPT-4o) < RCDI(Llama) — NOTE the surrogate/transfer confound; interpret cautiously.
- H5: RCDI(GPT-4o) ≥ 0.65.
- H6: GADA-N⁺ beats all baselines on the composite metric at corrected p < 0.001.

## Adaptive-attacker hypotheses (C6a–C6c) — set thresholds now
- H-A1: HCR remains 0 under A1 (awareness only).
- H-A2: DDR(A2) > DDR(A0) significantly; HCR(A2) ≤ **[X]%**.
- H-A3: HCR(A3) non-zero but ≤ **[Y]%**; MADT(A3) ≫ no-defence ceiling.
- H-A-transfer: awareness raises GPT-4o HCR more than Llama HCR.
- **Do NOT pre-commit to "still 0%".** A graceful-degradation curve is an acceptable, credible outcome.

## Analysis (fixed in advance)
- Welch t (or Mann–Whitney if non-normal); Cohen's d / Cliff's delta; Holm–Bonferroni per family; Clopper–Pearson for all proportions.
- RCDI per the measurement protocol: deterministic rule checker + 10% human sample, report Cohen's κ (≥0.7 target); no LLM judge.
- Prompt-robustness: ≥3 attacker system-prompt paraphrases at the default awareness; report spread.

## Stopping / exclusions
- Fixed episode budget (no optional stopping). Exclusion rule for malformed LLM outputs: ____________.
