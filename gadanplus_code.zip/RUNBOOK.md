# RUNBOOK — GADA-N⁺ real experiments, end to end

Records the four locked decisions (2026-07-03) and the exact sequence from a
fresh machine to filled tables. Anything marked **[you]** needs your hardware /
license acceptance / credentials; the rest I have built and tested.

## Locked decisions
1. **Environment source:** keep the harness real-env-ready behind the frozen
   presentation-id + leakage contract; drop in your real GADA-N env when
   available (else specialise from the dataset). *Contract enforced by
   `integrity.leakage_scan` + `tests/`.*
2. **Compute (revised — verified no NVIDIA GPU: i7-8565U / Intel UHD 620):** CPU
   for the pipeline + small-cGAN prototyping; **free cloud GPU (Colab/Kaggle)**
   for real cGAN training. No CUDA/driver install. *`SETUP_GPU_AND_CREDENTIALS.md`.*
3. **Dataset:** **TON_IoT** primary (column-adaptive loader, so switching is
   cheap). *`gadanplus/data.py`, `DATA_REQUIREMENTS.md`.*
4. **Backends (revised — no local GPU):** Llama-3.1 via a **hosted OpenAI-compatible
   endpoint** (Together/Fireworks) for both surrogate `L_ling` and the eval
   attacker; **GPT-4o** as a paid black-box eval slice. No local model weights.
   *`attacker.py`, `gde.LlamaPerplexityScorer`.*

## Sequence
0. **[you] Setup** — follow `SETUP_GPU_AND_CREDENTIALS.md` (NVIDIA driver; conda
   `gadan` env; cu128 torch; HF/Kaggle/OpenAI/Llama-endpoint credentials).
   Then: `python scripts/check_env.py` → all green.
1. **Validate the pipeline (no creds)** — `python tests/test_pipeline.py` (12/12)
   and `python -m gadanplus.run_conditions --suite configs/suite_smoke.yaml`
   (mock, NOT PAPER DATA).
2. **[you] Get data** — download TON_IoT into `data/ton_iot/` (Kaggle:
   `kaggle datasets download -d arnobbhowmik/ton-iot-network-dataset`), unzip.
3. **Train the GDE** — `python scripts/train_gde.py --data data/ton_iot/train.csv
   --label-col label --kind-col type --lambdas 0.01,0.1,1.0 --epochs 3000
   --out results/gde_ton_iot`. For the real L_ling, set `LLAMA_ENDPOINT` and swap
   `HeuristicScorer` → `LlamaPerplexityScorer(meta=meta)` in `train_gde.py`.
4. **Wire the generator into the env** — replace the LCAM stand-in in `env.py`
   with the trained generator's output; **keep the presentation-id + schema
   contract** so `leakage_scan` stays clean (the tests enforce this).
5. **[you] Freeze `PREREG.md`** — fill the A2/A3 [X]/[Y] thresholds + exclusion
   rule (already implemented); set freeze date + `git rev-parse HEAD`.
6. **Run the studies** —
   `python -m gadanplus.run_conditions --suite configs/suite_main.yaml`      (C1–C5)
   `python -m gadanplus.run_conditions --suite configs/suite_adaptive.yaml`  (C6a–c)
   `python -m gadanplus.run_conditions --suite configs/suite_robustness.yaml`
   Each writes `tables.tex` (incl. `tab:adaptive`), figures, per-condition
   summaries + a **leakage audit** (real-backend leak = ERROR: do not report).
7. **RCDI validation** — `metrics.export_human_sample`; two annotators; report
   Cohen's κ (≥0.7).
8. **Fill the manuscript** — paste `results/*/tables.tex` into `main.tex`
   (`tab:adaptive` + narrative). **Verify** the surrogate framing
   (`%% AUTHOR VERIFY`). Recompile in Overleaf.
9. **[you] ARL prepublication clearance → co-author sign-off → venue**
   (SaTML / AISec / MILCOM).

## Integrity gates (do not bypass)
- Real-backend `leakage_scan` must be **clean** before reporting DDR / AUROC.
- No number without a saved artifact (manifest + seeds + config hash).
- Mock output is NOT PAPER DATA (banner + table/figure stamps).
